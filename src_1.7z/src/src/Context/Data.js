import React, {createContext} from "react";
import data from '../data/data';

export const DataContext = createContext([{}, () => {}]);

export const DataProvider = ({children}) => (
  <DataContext.Provider value={data}>
    {children}
  </DataContext.Provider>
);
