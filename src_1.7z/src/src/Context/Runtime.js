import React, {createContext, useState} from "react";

export const RuntimeContext = createContext([{}, () => {}]);

export const RuntimeProvider = ({children}) => {
  const [state, setState] = useState({id: 0, branch: 'orange', checked: [], calculation: 0});

  return (
    <RuntimeContext.Provider value={[state, setState]}>
      {children}
    </RuntimeContext.Provider>
  )
};
