import React from "react";
import bg from './assets/img/bg.jpg';
import ReactDOM from 'react-dom';
import {DataProvider} from "./Context/Data";
import {RuntimeProvider} from "./Context/Runtime";
import styled, {createGlobalStyle} from "styled-components";
import WelcomeScreen from "./components/WelcomeScreen";
import franklinWoff from './assets/fonts/FranklinGothicHeavy.woff';
import franklinWoff2 from './assets/fonts/FranklinGothicHeavy.woff2';

const GlobalStyle = createGlobalStyle`
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: Montserrat;
    font-weight: 500;
  }
  @font-face {
    font-family: "FranklinGothicHeavy";
    src: url(${franklinWoff}) format("woff"),
        url(${franklinWoff2}) format("woff2");
    font-display: swap;
    font-weight: 900;
  }
`;


const StyledApp = styled.div`
  width: 100%;
  height: 100%;
  min-height: 100vh;
  
  display: flex;
  margin: 0;
  padding: 0;
  
  background: url(${bg}) no-repeat center center;
  background-size: cover;
`;

const App = () => (
  <DataProvider>
    <RuntimeProvider>
      <GlobalStyle/>
      <StyledApp id={'app'}>
        <WelcomeScreen/>
      </StyledApp>
    </RuntimeProvider>
  </DataProvider>
);

ReactDOM.render(<App/>, document.querySelector('#root'));

