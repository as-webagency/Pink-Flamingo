import {useState} from "react";
import calculation from '../data/calculation';

/**
 * @param data {Array}
 * @return {[Number, Function]}
 */
const useCalculation = (data) => {
  const calculate = data => (
    data.reduce((prev, e, i) => {
      if (calculation[i])
        return prev + +calculation[i][e];
      if (i === data.length-1) {
        return prev * data[3];
      }
      return prev;
    }, 0)
  );
  const [state, setState] = useState(calculate(data));

  return [state, setState];
};

export default useCalculation;
