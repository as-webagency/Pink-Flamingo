import React from "react";
import styled from "styled-components";
import InputRange from "react-input-range";
import 'react-input-range/lib/css/index.css';

const StyledRange = styled.div`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  padding: 20px 30px;
  max-width: 100%;
`;
const Question = styled.header`
  margin-bottom: 30px;
`;

const Input = styled.input`
  margin-top: 40px;
  
  max-width: 100%;
  width: 470px;
  height: 60px;
  border-radius: 56px;
  
  border: 1px solid #c4c4c4;
  box-shadow: inset 0 2px 1px rgba(0, 0, 0, 0.25);
  
  font-weight: 500;
  font-size: 18px;
  line-height: 22px;
  color: #090808;
  padding-left: 18px;
  
  &:focus {
    border: 1px solid #FCBE24;
    outline: none;
  }
  
  @media (max-width: 550px) {
    width: auto;
  }
`;

const Range = ({question, params, onChange, id, state}) => {
  const [minValue, maxValue] = params;
  const onInputChange = ({target: {value: v}}) => {
    if (!isFinite(v)) return;
    if (+v > maxValue) return onChange(id, +maxValue);
    if (+v < minValue) return onChange(id, +minValue);
    onChange(id, +v);
  };
  return (
    <StyledRange>
      <Question>{question}</Question>
      <InputRange
        formatLabel={v => `${v} м2`}
        onChange={v => onChange(id, v)}
        value={state.checked[id] || +minValue}
        maxValue={+maxValue}
        minValue={+minValue}
      />
      <Input type='text' value={state.checked[id] || ''} onChange={onInputChange}/>
    </StyledRange>//(state.checked[id] || minValue) + description
  )
};

export default Range;
