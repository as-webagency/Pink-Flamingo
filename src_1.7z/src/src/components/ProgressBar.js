import React from "react";
import styled from "styled-components";

// const animation = keyframes`
//   0%{background-position:1rem 0}to{background-position:0 0}   animation: ${animation} 1s linear infinite;
// `;  background-image: linear-gradient(45deg,hsla(0,0%,100%,.15) 25%,transparent 0,transparent 50%,hsla(0,0%,100%,.15) 0,hsla(0,0%,100%,.15) 75%,transparent 0,transparent);

const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  height: 1rem;
  overflow: hidden;
  font-size: .75rem;
  background-color: #e9ecef;
  border-radius: .25rem;
  width: 100%;
  align-self: center;
  margin-bottom: 51px;
`;
const Bar = styled.div`
  width: ${props => props.progress}%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  color: #fff;
  text-align: center;
  white-space: nowrap;
  background-color: #007bff;
  transition: width .6s ease;
  height: 16px;
  border-radius: 3px;
  
  background-color: #FCBE24;
  background-size: 1rem 1rem;
`;
const BarHeader = styled.div`
  margin: 48px 0 25px;
  font-weight: 500;
  font-size: 18px;
  line-height: 22px;
  color: #c4c4c4;
  
  @media (max-width: 550px) {
    font-size: 12px;
    line-height: 15px;
  }
`;

const ProgressBar = ({progress}) => {

  return (
    <>
      <BarHeader>Расчет выполнен на {Math.round(progress)}%</BarHeader>
      <Wrapper>
        <Bar progress={progress}/>
      </Wrapper>
    </>
  );
};

export default ProgressBar;
