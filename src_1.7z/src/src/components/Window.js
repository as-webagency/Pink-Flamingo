import React, {useContext, useEffect, useRef} from "react";
import styled from "styled-components";
import {DataContext} from "../Context/Data";
import {RuntimeContext} from "../Context/Runtime";
import Button from "./Button";
import Radio from "./Radio";
import Textarea from "./Textarea";
import Message from "./Message";
import Present from "./Present";
import Input from "./Input";
import Final from "./Final";
import Range from "./Range";
import ProgressBar from "./ProgressBar";
import Header from "./Header";

const StyledWindow = styled.div`
  min-height: 75vh;
  min-width: 67%;
  padding: 3.67% 4% 2.8% 4%;
  
  display: flex;
  position: absolute;
  top: 14%;
  left: 50%;
  transform: translateX(-50%);
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  background-color: #fff;
  border-radius: 14px;
  
  @media (max-width: 1200px) {
    width: 96%;
  }
  @media (max-width: 768px) {
    padding-top: 26px;
  }
  @media (max-width: 460px) {
    top: 16%;
  }
`;
const ButtonsWrapper = styled.div`
  height: 100px;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #fff;
`;

const Window = ({setAppStatus}) => {
  const data = useContext(DataContext);
  const [state, setState] = useContext(RuntimeContext);
  const mainFrame = useRef(null);

  const onMainStateChange = (id, payload) => {
    setState(state => {
      const {id: presentId} = data.find(e => e.type === 'present');
      const {id: inputId} = data.find(e => e.type === 'input');
      const {checked} = state;
      checked[id] = payload;

      if (+id === 1) {
        const greenBranch = data.find(e => e.id === 1).answers.green.text.filter((_, i) => i > 1);

        return {
          ...state,
          checked,
          branch: greenBranch.includes(payload) ? 'green' : 'orange',
        };
      }
      if (+id !== presentId && +id !== inputId)
        checked[presentId] = null; //clearing present data to prevent fails, then user changes his data and lose accesses to checked present

      return {
        ...state,
        checked,
      }
    });
  };
  const renderBody = () => {
    const currentSlide = data.find(e => e.id === state.id);
    const props = {
      state, setState, ...currentSlide
    };

    switch(currentSlide.type) {
      case 'radio': return <Radio {...props} onClick={onMainStateChange}/>;
      case 'range': return <Range {...props} onChange={onMainStateChange}/>;
      case 'textarea': return <Textarea {...props} onChange={onMainStateChange}/>;
      case 'message': return <Message {...props}/>;
      case 'present': return <Present {...props} onClick={onMainStateChange}/>;
      case 'input': return <Input {...props} onChange={onMainStateChange}/>;
      case 'final': return <Final {...props} data={data} setAppStatus={setAppStatus}/>;
      default: return <div>Something goes wrong</div>;
    }
  };
  const onNavButtonClick = (next) => {
    setState(state => {
      const lastStep = data.length-1;
      const penultimateStep = lastStep -1;
      const nextSlide = state.id + 1;
      const prevSlide = state.id - 1;

      const {id: messageSlideId} = data.find(e => e.type === 'message');
      const {id: presentSlideId} = data.find(e => e.type === 'present');
      const prevPresentSlideId = presentSlideId - 1;
      const {id: inputSlide} = data.find(e => e.type === 'input');

      const isFirstSlide = state.id === 0;
      const isPartialRepair = state.checked[4] === 'Частичный';
      const isInputSlide = state.id === inputSlide;
      const isPenultimateStep = state.id === penultimateStep;
      const isPrevPresentSlide = state.id === prevPresentSlideId;
      const isMessageSlide = state.id === messageSlideId;
      const isLastSlide = state.id === data[lastStep].id;

      const getLowerPresents = () => {
        const presentValues = Object.keys(data[presentSlideId]['presents']).map(e => +e);
        return Math.min(...presentValues);
      };
      const isCalculationHigherThanMinPresent = () => (+state.calculation / 1000) < getLowerPresents();

      if (isFirstSlide && !next) return state;
      if (isLastSlide && next) return state;


      if (isMessageSlide) {
        if (isPartialRepair)
          return {
            ...state,
            id: next ? penultimateStep : 0,
          };

        return {
          ...state,
          id: next ? nextSlide : 0,
        }
      }

      if (isPenultimateStep && isPartialRepair)
        return {
          ...state,
          id: next ? lastStep : messageSlideId,
        };
      if (isPrevPresentSlide && isCalculationHigherThanMinPresent())
        return {
          ...state,
          id: next ? nextSlide + 1 : prevSlide,
        };
      if (isInputSlide && isCalculationHigherThanMinPresent())
        return {
          ...state,
          id: next ? nextSlide : prevSlide - 1,
        };

      return {
        ...state,
        id: next ? nextSlide : prevSlide,
      }
    });
  };
  const renderButtons = () => {
    const {id, checked} = state;
    const isFirstSlide = id === 0;
    const isAnswered = !!checked[id] || checked[id] === 0;
    const isLastSlide = data.length - 1 === +id;
    const penultimateSlide = data.length - 2;
    const {required} = data[id];
    const {id: inputSlideId} = data.find(e => e.type === 'input');
    const {id: messageSlideId} = data.find(e => e.type === 'message');
    const isInputSlide = inputSlideId === id;
    const isMessageSlide = state.id === messageSlideId;
    const isPenultimateSlide = state.id === penultimateSlide;

    const isInputStateOk = () => checked[inputSlideId] && Object.keys(checked[inputSlideId]).every(e => !!checked[inputSlideId][e]);

    const buttonsData = {
      0: {
        text: isMessageSlide ? 'Пройти тест заново' : '',
        key: 'prev',
        onClick: onNavButtonClick.bind(null, false),
        disabled: isFirstSlide,
        id: id,
        isMessageSlide,
      },
      1: {
        text: isPenultimateSlide ? 'Отправить' : 'Далее',
        key: 'next',
        onClick: required ? (isAnswered ? onNavButtonClick.bind(null, true) : () => {}) : onNavButtonClick.bind(null, true),
        disabled: required ? (isInputSlide && !isInputStateOk()) || !isAnswered || isLastSlide : false,
        id: id === data.length - 2 ? 'penultimateSlide' : 'nextButton',
        isMessageSlide,
      }
    };

    return new Array(2)
      .fill('')
      .map((_, i) => <Button {...buttonsData[i]}/>)
  };
  const getCurrentProgress = () => {
    const progress = (100 / 9) * +state.id;
    if (progress === 100) return 99;
    return progress;
  };

  useEffect(() => {
    const windowResize = () => {
      const windowHeight = mainFrame.current.offsetHeight;
      document.querySelector('#app').style.minHeight = `${+windowHeight + 300}px`;
    };

    windowResize();
  }, [state]);

  return (
    <StyledWindow ref={mainFrame}>
      {+state.id < 10 &&
        <>
          <Header/>
          <ProgressBar progress={getCurrentProgress()}/>
        </>}
      {renderBody()}
      {data.length - 1 === state.id ||
      <ButtonsWrapper>
        {renderButtons()}
      </ButtonsWrapper>}
    </StyledWindow>
  )
};

export default Window;
