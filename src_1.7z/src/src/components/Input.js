import React, {useEffect, useState} from "react";
import styled from "styled-components";
import acceptImg from  './../assets/img/tick.svg';
import InputMask from 'react-input-mask';
import '../assets/css/style.css';

const StyledInput = styled.div`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  width: 100%;
  justify-content: center;
  align-items: center;
  padding-bottom: 60px;
`;
const Header = styled.header`
  font-weight: 500;
  font-size: 30px;
  line-height: 37px;
  margin-bottom: 70px;
`;
const Inputs = styled.input`
  max-width: 100%;
  width: 470px;
  height: 60px;
  border-radius: 56px;
  margin-top: 10px;
  
  border: 1px solid #c4c4c4;
  box-shadow: inset 0 2px 1px rgba(0, 0, 0, 0.25);
  
  font-weight: 500;
  font-size: 18px;
  line-height: 22px;
  color: #090808;
  padding-left: 18px;
  
  &:focus {
    border: 1px solid #FCBE24;
    outline: none;
  }
  
  @media (max-width: 550px) {
    width: auto;
  }
`;
const InputWrapper = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Label = styled.label`
  display: flex;
  flex-direction: column;
  margin-bottom: 20px;
  font-size: 18px;
  line-height: 22px;
  color: #000;
  font-weight: 400;
  text-indent: 20px;
`;
const CheckboxLabel = styled.label`
  font-weight: 300;
  font-size: 14px;
  line-height: 17px;
  color: #000;
  max-width: 100%;
  width: 470px;
  display: flex;
  
  @media (max-width: 550px) {
    width: auto;
  }
`;
const Checkbox = styled.input`
  margin-bottom: 6px;
  position: absolute;
  display: none;
`;
const CheckboxWrapper = styled.div`
  width: 30px;
  height: 18px;
  border: 1px solid #c4c4c4;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  margin-right: 10px;
  
  @media (max-width: 550px) {
    width: 50px;
  }
    ${props => props.checked && `
    &::after {
      content: '';
      position: absolute;
      width: 20px;
      height: 18px;
      background: url(${acceptImg}) no-repeat center;
      left: calc(50% - 9px);
      top: calc(50% - 9px);
    }
  `}
`;

const Input = ({header, inputs, onChange, id, state: {checked}}) => {
  const [agree, setAgree] = useState(false);
  const onInputChange = ({target: {value}}, name) => {
    let result = {
      ...checked[id],
      [name]: value,
    };

    inputs.forEach(({name}) => {
      if (!result[name]) result[name] = '';
    });

    onChange(id, result);
  };
  const renderInput = (data) => (
    data.map(({name, text, placeholder}) => {
      const value = (checked[id] && checked[id][name]) || '';
      const isPhone = name === 'phone';

      return (
        <Label htmlFor={name} key={name}>
          {text}
          {isPhone ?
            <InputMask type='tel' id={name} name='text' placeholder={placeholder} onChange={evt => onInputChange(evt, name)} value={value} className={'phone-input'} mask="+7\ 999 999 99 99" pattern={'[0-9,+, ]{16,16}'}/> :
            <Inputs type='text' id={name} name='text' placeholder={placeholder} onChange={evt => onInputChange(evt, name)} value={value}/>}
        </Label>
      )
    })
  );
  const onAgreeChange = () => setAgree(state => !state);

  useEffect(() => {
    onInputChange({target: {value: agree}}, 'agree');
  }, [agree]);

  return (
    <StyledInput>
      <Header>{header}</Header>
      <InputWrapper>
        {renderInput(inputs)}
        <CheckboxLabel htmlFor="checkbox">
          <CheckboxWrapper checked={agree}>
            <Checkbox type="checkbox" value={agree} onChange={onAgreeChange} id={'checkbox'}/>
          </CheckboxWrapper>
          <p>Я ознакомлен с <a target='_blank' rel='noopener noreferrer' href={'./police.html'}>политикой конфиденциальности и согласием на обработку персональных данных</a></p>
        </CheckboxLabel>
      </InputWrapper>
    </StyledInput>
  )
};

export default Input;
