import React from "react";
import styled from "styled-components";
import btnArrow from './../assets/img/btn-arrow.svg';
import btnArrowGray from './../assets/img/btn-arrow--gray.svg';
import btnArrowOrange from './../assets/img/btn-arrow--orange.svg';
import presentBtnImg from './../assets/img/present-icon.png';

const StyledButton = styled.button`
  ${({id, isMessageSlide}) => {
    const nextButtonStyle = `
      background: #FFD540;
      box-shadow: inset 0 -4px 0 0 #DEAB1D;
      border: none;
      border-radius: 84px;
      width: 201px;
      height: 55px;
      position: relative;
      transition: ease .3s;
      
      color: #fff;
      font-size: 18px;
      line-height: 22px;
      
      &:hover {
        background: #FFD540;
        box-shadow: inset 0 4px 0 0 #DEAB1D;
        cursor: pointer;
      }
      
      &:focus {
        outline: none;
      }
      
      &::after {
        content: '';
        width: 22px;
        height: 10px;
        background: url(${btnArrow}) no-repeat center;
        position: absolute;
        right: 40px;
        top: 24px;
      }
      
      @media (max-width: 550px) {
        &::after {
          display: none;
        }
      }
      `;
    const prevButtonStyle = `
      width: 55px;
      height: 55px;
      background: url(${btnArrowGray}) no-repeat center;
        size: 22px 1px;
      border: 1px solid #C4C4C4;
      border-radius: 50%;
      margin-right: 20px;
      
      &:focus {
        outline: none;
      }
      
      &:hover {
        cursor: pointer;
        background: url(${btnArrowOrange}) no-repeat center;
          size: 22px 1px;
        border: 1px solid #FCBE24;
      }
    `;
    const messageSlideButton = `
      background: #FFD540;
      box-shadow: inset 0 -4px 0 0 #DEAB1D;
      border: none;
      border-radius: 84px;
      width: 220px;
      height: 55px;
      margin-right: 35px;
      transition: ease .3s;
      
      color: #fff;
      font-size: 18px;
      line-height: 22px;
      
      &:hover {
        background: #FFD540;
        box-shadow: inset 0 4px 0 0 #DEAB1D;
        cursor: pointer;
      }
      
      &:focus {
        outline: none;
      }
      
      @media (max-width: 550px) {
        margin-right: 15px;
      }
    `;
    const messageSlideNextButton = nextButtonStyle + `
      @media (min-width: 1700px) {
        &::before {
          content: '';
          width: 336px;
          height: 205px;
          background: url(${presentBtnImg}) no-repeat center;
          position: absolute;
          right: -337px;
          top: -121px;
        }
      }
    `;
    if (id === 13) return `display: none`;
    if (id === 'penultimateSlide')
      return nextButtonStyle + `&::after {display: none}`;
    if (isMessageSlide)
      if (id === 'nextButton') return messageSlideNextButton;
      else return messageSlideButton;
    if (id === 'nextButton') return nextButtonStyle;
    else return prevButtonStyle;
  }};
`;

const Button = ({text, ...rest}) => (
  <StyledButton {...rest}>
    {text}
  </StyledButton>
);

export default Button;
