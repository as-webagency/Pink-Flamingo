import React from "react";
import styled from "styled-components";

const StyledHeader = styled.header`
  font-weight: 500;
  font-size: 20px;
  line-height: 24px;
  color: #100E0E;
  
  @media (max-width: 768px) {
    font-size: 18px;
    line-height: 22px;
  }
  
  @media (max-width: 550px) {
    text-align: center;
    font-size: 14px;
    line-height: 17px;
  }
`;
const OrangePart = styled.span`
  color: #FCBE24;
  line-height: inherit;
  font-size: inherit;
  font-weight: inherit;
`;

const Header = () => (
  <StyledHeader>
    Пройдите тест и узнайте стоимость будущего ремонта <OrangePart>за 1 минуту</OrangePart>
  </StyledHeader>
);

export default Header;
