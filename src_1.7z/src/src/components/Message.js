import React, {useEffect} from "react";
import styled from "styled-components";
import useCalculation from "../hooks/useCalculation";

const StyledMessage = styled.div`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  width: 100%;
  padding-bottom: 40px;
`;
const Header = styled.header`
  font-size: 30px;
  line-height: 37px;
  color: #000;
  font-weight: 500;
  margin-bottom: 70px;
  align-self: center;
  
  @media (max-width: 450px) {
    font-size: 20px;
    line-height: 25px;
  }
`;
const SubHeader = styled.div`
  font-size: 25px;
  line-height: 30px;
  color: #090808;
  font-weight: 500;
  margin-bottom: 50px;
  align-self: center;
  
  @media (max-width: 400px) {
    font-size: 20px;
    line-height: 25px;
  }
`;
const EstimateWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin-left: 13%;
  
  @media (max-width: 400px) {
    margin-left: 0;
  }
`;
const TopEstimate = styled.ul`
  list-style-type: none;
  margin-bottom: 30px;
`;
const CalculationEstimate = styled.div`
  font-weight: 400;
`;
const BottomEstimate = styled.div`
  display: flex;
  flex-direction: column;
  color: #000;
  font-size: 20px;
  line-height: 30px;
  font-weight: 700;
  
  @media (max-width: 400px) {
    font-size: 18px;
    line-height: 24px;
  }
`;
const EstimateItem = styled.li`
  color: #000;
  font-size: 20px;
  line-height: 30px;
  
  @media (max-width: 400px) {
    font-size: 18px;
    line-height: 24px;
  }
`;
const Strong = styled.strong`
  font-weight: 700;
`;

const Message = ({header, subheader, state, setState, id}) => {
  const [calculation] = useCalculation(state.checked);

  useEffect(() => {
    setState(state => ({
      ...state,
        calculation,
    }));
  }, [calculation, setState]);

  return (
    <StyledMessage>
      <Header>{header}</Header>
      <SubHeader>{subheader}</SubHeader>
      <EstimateWrapper>
        <TopEstimate>
          <EstimateItem><Strong>Тип Объекта: </Strong>{state.checked[1]}</EstimateItem>
          <EstimateItem><Strong>Ремонт: </Strong>{state.checked[4]}</EstimateItem>
          <EstimateItem><Strong>Площадь: </Strong>{state.checked[3]} кв.м</EstimateItem>
          <EstimateItem><Strong>Материалы: </Strong>{state.checked[5]}</EstimateItem>
          <EstimateItem><Strong>Объект: </Strong>{state.checked[6]}</EstimateItem>
          <EstimateItem><Strong>Дизайн-проект: </Strong>{state.checked[7]}</EstimateItem>
        </TopEstimate>
        <BottomEstimate>
          Предварительная смета:
          <CalculationEstimate>
            {calculation} руб.
          </CalculationEstimate>
        </BottomEstimate>
      </EstimateWrapper>
    </StyledMessage>
  )
};

export default Message;




// const вторичка = был_ремонт = 500; const новостройка = черновая = 0;
//
// const косметический = 1500; const ванная_и_туалет = 1500; const капитальный = 2500;
// const сам_куплю = 0; const поручу_вам = 1000;
// const в_городе = 0; const за_городом = 1000;
// const есть = 500; const нет_и_не_будет = 0; const планирую_заказать = 1000;
