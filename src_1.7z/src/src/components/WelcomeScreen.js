import React, {useState} from "react";
import Window from "./Window";
import styled, {keyframes} from "styled-components";
import data from '../data/WelcomeScreenData';
import calculator from '../assets/img/calculator.png';
import {animateScroll} from 'react-scroll';

const animation = keyframes`
    0% { left: -30px; margin-left: 0px; }
    30% { left: 110%; margin-left: 80px; }
    100% { left: 110%; margin-left: 80px; };
`;

const Wrapper = styled.section`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  margin: 0 16.8%;
  
  @media (max-width: 1200px) {
    margin: 0 2%;
  }
`;
const Header = styled.header`
  margin-top: 29px;
  display: flex;
  justify-content: space-between;
  margin-bottom: 70px;
  
  @media (max-width: 630px) {
    flex-direction: column;
    align-items: center;
  }
`;
const LogoWrapper = styled.div`
  display: flex;
  
  @media (max-width: 630px) {
    margin-bottom: 30px;
  }
  
  @media (max-width: 400px) {
    justify-content: space-between;
  }
`;
const Logo = styled.p`
  padding: 10px 14px;
  border: 8px solid #fff;
  color: #fff;
  font-size: 50px;
  font-weight: 700;
  
  @media (max-width: 400px) {
    font-size: 25px;
    line-height: 30px;
    border: 4px solid #fff;
  }
`;
const LogoInfo = styled.div`
  margin-left: 20px;
  display: flex;
  flex-direction: column;
  align-self: center;
  align-items: center;
`;
const LogoInfoName = styled.div`
  font-weight: 700;
  font-size: 26px;
  line-height: 32px;
  text-transform: uppercase;
  color: #fff;
`;
const LogoInfoDescription = styled.div`
  font-weight: 400;
  font-size: 11px;
  line-height: 13px;
  letter-spacing: -.01em;
  color: #fff;
  border-top: 1px solid #fff;  
`;
const HeaderInfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  
  @media (max-width: 550px) {
    align-self: center;
  }
`;
const HeaderInfoSchedule = styled.div`
  color: #fff;
  line-height: 24px;
  font-size: 20px;
  font-weight: 500;
`;
const HeaderInfoPhone = styled.a`
  font-weight: 700;
  font-size: 30px;
  color: #fcbe24;
  text-align: right;
  
  @media (max-width: 930px) {
    font-size: 25px;
  }
  
  @media (max-width: 550px) {
    text-align: center;
    font-size: 20px;
  }
`;
const Main = styled.main`
  display: flex;
  flex-direction: column;
  
  @media (max-width: 400px) {
    align-items: center;
  }
`;
const MainHeader = styled.header`
  font-weight: 500;
  font-size: 35px;
  color: #fff;
  margin-bottom: 16px;
  
  @media (max-width: 930px) {
    font-size: 30px;
    margin-bottom: 27px;
  }
  
  @media (max-width: 550px) {
    text-align: center;
    font-size: 20px;
  }
`;
const MainSubHeader = styled.p`
  font-family: FranklinGothicHeavy;
  font-weight: 400;
  font-size: 50px;
  color: #fff;
  max-width: 720px;
  
  @media (max-width: 930px) {
    font-size: 45px;
  }
  
  @media (max-width: 550px) {
    text-align: center;
    font-size: 25px;
  }
  
  @media (max-width: 360px) {
    max-width: 80%;
  }
`;
const MainSubHeaderYellow = styled.span`
  color: #E8B607;
  font-family: inherit;
  font-weight: inherit;
`;
const BenefitsHeader = styled.div`
  margin-top: 37px;
  
  font-weight: 500;
  font-size: 30px;
  color: #fff;
  
  @media (max-width: 930px) {
    font-size: 25px;
    line-height: 30px;
  }
  
  @media (max-width: 550px) {
    text-align: center;
    font-size: 20px;
    line-height: 24px;
  }
`;
const BenefitsWrapper = styled.ul`
  margin: 35px 0 86px;
  display: flex;
  
  @media (max-width: 680px) {
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
  }
  
  @media (max-width: 550px) {
      margin: 35px 0 40px;
  }
`;
const Benefit = styled.li`
  display: flex;
  margin-right: 7%;
  
  &:last-of-type {
    margin-right: 0px;
  }
  
  @media (max-width: 930px) {
    margin-right: 4.5%;
  }
  @media (max-width: 680px) {
    margin-bottom: 34px;
  }
  @media (max-width: 400px) {
    margin-right: 0;
    width: 300px;
  }
`;
const BenefitLogoWrapper = styled.div`
  width: 150px;
  height: 150px;
  
  
  @media (max-width: 400px) {
    width: 80px;
    height: 80px;
  }
`;
const BenefitLogo = styled.img`
  max-width: 100%;
`;
const BenefitInfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
  padding-top: 20px;
`;
const BenefitInfoHeader = styled.p`
  font-weight: 700;
  font-size: 25px;
  line-height: 30px;
  color: #fff;
  margin-bottom: 3px;
  max-width: 225px;
  
  @media (max-width: 930px) {
    font-size: 20px;
    line-height: 24px;
  }
  @media (max-width: 550px) {
    font-size: 18px;
    line-height: 22px;
  }
`;
const BenefitInfoDescription = styled.p`
  font-weight: 500;
  font-size: 18px;
  line-height: 22px;
  color: #fff;
  
  @media (max-width: 550px) {
    font-size: 16px;
    line-height: 20px;
  }
`;
const KvizButtonWrapper = styled.div`
  position: relative;
  width: 445px;
  margin-bottom: 40px;
    
  @media (max-width: 550px) {
    width: 305px;
    align-self: center;
  }
  
  @media (max-width: 450px) {
    align-self: unset;
    margin-left: 8%;
  }
  
  @media (max-width: 450px) {
    width: 260px;
    margin-left: 10%;
  }
  
  @media (max-width: 400px) {
    margin-left: 8%;
  }
  
  @media (max-width: 360px) {
    margin-left: 0%
  }
`;
const KvizCalculator = styled.div`
  background: url(${calculator}) no-repeat;
  position: absolute;
  right: -40px;
  top: 0;
  width: 114px;
  height: 122px;
  z-index: 2;
  
  @media (max-width: 550px) {
    right: -60px;
  }
  
  @media (max-width: 450px) {
    width: 80px;
    background-size: contain;
    right: -25px;
  }
`;
const CallKvizButton = styled.button`
  background: #FCBE24;
  box-shadow: inset 0 -8px 0px 0px #DEAB1D;
  border: none;
  border-radius: 84px;
  width: 445px;
  height: 87px;
  position: relative;
  transition: ease .3s;
  
  color: #090808;
  font-family: FranklinGothicHeavy;
  font-size: 20px;
  line-height: 23px;
  overflow: hidden;
  
  &:hover {
    background: #FCBE24;
    box-shadow: inset 0  8px 0px 0px #DEAB1D;
    cursor: pointer;
  }
  
  &::before {
    content: '';
    display: block;
    width: 30px;
    height: 300px;
    margin-left: 60px;
    background: linear-gradient(to bottom, rgba(255,255,255,0.7) 0%,rgba(255,255,255,1) 50%,rgba(255,255,255,0.7) 100%);
    position: absolute;
    left: -40px;
    top: -150px;
    z-index: 1;
    transform: rotate(45deg);
    transition: all .1s;
    animation: ${animation} 3s 0.05s ease-in-out infinite;
  }
  
  @media (max-width: 550px) {
    width: 300px;
    font-size: 15px;
    line-height: 17px;
  }
  
  @media (max-width: 450px) {
    width: 240px;
    font-size: 12px;
    line-height: 1.2;
  }
`;
const KvizButtonPresent = styled.div`
  font-weight: 500;
  font-size: 25px;
  line-height: 30px;
  color: #fff;
`;

const WelcomeScreen = () => {
  const [state, setState] = useState(false);
  const onLinkClick = () => {
    animateScroll.scrollToTop();
    setState(true);
  };
  const {header, main} = data;

  return (
    <Wrapper>
      <Header>
        <LogoWrapper>
          <Logo>{header.logo}</Logo>
          <LogoInfo>
            <LogoInfoName>{header.logoInfoName}</LogoInfoName>
            <LogoInfoDescription>{header.logoInfoDescription}</LogoInfoDescription>
          </LogoInfo>
        </LogoWrapper>
        <HeaderInfoWrapper>
          <HeaderInfoSchedule>{header.schedule}</HeaderInfoSchedule>
          <HeaderInfoPhone>{header.phone}</HeaderInfoPhone>
        </HeaderInfoWrapper>
      </Header>
      <Main>
        <MainHeader>{main.header}</MainHeader>
        <MainSubHeader>
          {main.subheader1}
          <MainSubHeaderYellow>{' ' + main.subheaderYellow + ' '}</MainSubHeaderYellow>
          {main.subheader2}
        </MainSubHeader>
        <BenefitsHeader>{main.benefitsHeader}</BenefitsHeader>
        <BenefitsWrapper>
          {main.benefits.map(e =>
            <Benefit key={e.src}>
              <BenefitLogoWrapper>
                <BenefitLogo src={e.src}/>
              </BenefitLogoWrapper>
              <BenefitInfoWrapper>
                <BenefitInfoHeader>{e.header}</BenefitInfoHeader>
                <BenefitInfoDescription>{e.description1}</BenefitInfoDescription>
                <BenefitInfoDescription>{e.description2}</BenefitInfoDescription>
              </BenefitInfoWrapper>
            </Benefit>)
          }
        </BenefitsWrapper>
        {state ?
          <Window setAppStatus={setState}/> :
          <KvizButtonWrapper>
            <CallKvizButton onClick={onLinkClick}>
              {main.kvizCallButtonHeader}
              <KvizButtonPresent>{main.kvizCallButtonDescription}</KvizButtonPresent>
            </CallKvizButton>
            <KvizCalculator/>
          </KvizButtonWrapper>}
      </Main>
    </Wrapper>
  )
};

export default WelcomeScreen;
