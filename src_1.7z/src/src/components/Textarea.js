import React from "react";
import styled from "styled-components";

const StyledTextarea = styled.div`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  padding-bottom: 60px;
`;
const Header = styled.header`
  font-weight: 500;
  font-size: 30px;
  line-height: 37px;
  color: #090808;
  margin-bottom: 40px;
  align-self: center;
`;
const SubHeader = styled.header`
  color: #090808;
  font-size: 18px;
  line-height: 22px;
  margin-bottom: 16px;
`;
const InputTextArea = styled.textarea`
  min-width: 280px;
  width: 65%;
  height: 20%;
  min-height: 190px;
  resize: none;
  border: 1px solid;
  
  padding: 10px;
  color: #c4c4c4;
  font-weight: 500;
  font-size: 18px;
  line-height: 22px;
`;

const Textarea = ({header, subheader, placeholder, state, onChange, id}) => {
  return (
    <StyledTextarea>
      <Header>{header}</Header>
      <SubHeader>{subheader}</SubHeader>
      <InputTextArea placeholder={placeholder} value={state.checked[id]} onChange={({target: {value}}) => onChange(id, value)}/>
    </StyledTextarea> //onChange needs to repair (probably new function)
  )
};

export default Textarea;
