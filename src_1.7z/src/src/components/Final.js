import React from "react";
import styled from "styled-components";
import finalLogo from '../assets/img/final-screen-tick.svg';

const StyledFinal = styled.div`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: center;
`;
const LogoWrapper = styled.div`
  width: 136px;
  height: 105px;
`;
const Logo = styled.img`
  max-width: 100%;
`;

const Header = styled.header`
  max-width: 400px;
  color: #000;
  text-align: center;
  font-size: 25px;
  line-height: 30px;
  font-weight: 500;
`;
const ButtonsWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
const LinkToSite = styled.a`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 17px;
  text-decoration: none;

  background: #FFD540;
  box-shadow: inset 0 -4px 0 0 #DEAB1D;
  border: none;
  border-radius: 84px;
  width: 201px;
  height: 55px;
  position: relative;
  transition: ease .3s;
  
  color: #fff;
  font-size: 18px;
  line-height: 22px;
  
  &:hover {
    background: #FFD540;
    box-shadow: inset 0 4px 0 0 #DEAB1D;
    cursor: pointer;
  }
`;
const CloseButton = styled.button`
  border: none;
  background: transparent;
  
  color: #c4c4c4;
  
  font-weight: 500;
  font-size: 18px;
  line-height: 22px;
`;

const Final = ({header, state: {checked, calculation}, data, setAppStatus}) => {
  const prepareData = () => {
    const result = {
      'sum': calculation
    };
    data.forEach(({type, question, header, id}) => {
      switch(type) {
        case 'radio': return result[question] = String(checked[id]);
        case 'textarea': return result[header] = String(checked[id]) || '------';
        case 'present': return result[header] = String(checked[id]) || '------';
        case 'range': return result[question] = String(checked[id]);
        case 'input': return result[header] = String(checked[id]);
        default: return;
      }
    });

    return result;
  };
  const sendData = (data) => {
    const formData  = new FormData();

    Object.keys(data).forEach(k => {
      if (typeof data[k] === 'string' || typeof data[k] === 'number')
        formData.append(k, data[k]);
      else {
        Object.keys(data[k]).forEach(key => {
          formData.append(key, data[k][key]);
        })
      }
    });

    return formData;
  };

    fetch('./sendMail.php', {
      method: 'POST',
      body: sendData(prepareData()),
    })
      .catch(e => console.log(e));

  return (
    <StyledFinal>
      <LogoWrapper>
        <Logo src={finalLogo}/>
      </LogoWrapper>
      <Header>{header}</Header>
      <ButtonsWrapper>
        <LinkToSite href={'./'}>Перейти на сайт</LinkToSite>
        <CloseButton onClick={() => setAppStatus(false)}>Закрыть</CloseButton>
      </ButtonsWrapper>
    </StyledFinal>
  )
};

export default Final;
