import React from "react";
import styled from "styled-components";
// import {fadeIn} from 'react-animations';

// const bounceAnimation = keyframes`${fadeIn}`;

const StyledRadio = styled.form`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  background: #fff;
  width: 100%;
`;
const Question = styled.header`
  font-weight: 500;
  font-size: 30px;
  line-height: 37px;
  text-align: center;
  
  @media (max-width: 450px) {
    font-size: 20px;
    line-height: 25px;
  }
`;
const Answer = styled.input`
  margin-bottom: 6px;
  position: absolute;
  display: none;
`;
const AnswerWrapper = styled.div`
  flex-grow: 1;
  width: 100%;

  display: flex;
  ${({isPhoto}) => {
    if (!isPhoto) return `
      justify-content: center;
      align-items: center;
      flex-direction: column;
    `;
    else return `
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
    `;
  }}
  padding: 20px 0;
`;
const StyledLabel = styled.label`
  display: flex;
  margin-bottom: 20px;
  align-items: center;
`;
const AnswerText = styled.p`
  ${props => props.padding && 'padding-left: 10px'};
  font-size: 18px;
  line-height: 22px;
  font-weight: 500;
  color: #090808;
  
  @media (max-width: 450px) {
    font-size: 16px;
    line-height: 20px;
  }
`;
const PhotoLabel = styled.label`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin 0 20px 20px 0;
`;
const StyledPhoto = styled.img`
  margin-bottom: 10px;
  
  @media (max-width: 768px) {
    width: 150px;
    height: 150px;
  }
  
  @media (max-width: 550px) {
    width: 120px;
    height: 120px;
  }
`;
const InputWrapper = styled.div`
  margin-bottom: 5px;
  width: 15px;
  height: 15px;
  border-radius: 50%;
  border: 1px solid #FCBE24;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
    ${props => props.checked && `
    &::after {
      content: '';
      position: absolute;
      width: 9px;
      height: 9px;
      border-radius: 50%;
      background-color: #FCBE24;
      left: calc(50% - 4.5px);
      top: calc(50% - 4.5px);
    }
  `}
`;
const CenterWrapper = styled.div`

`;

const Radio = ({state: {branch, checked}, question, answers, onClick, id}) => {
  const renderAnswer = (data) => {
    const photos = data.photos;
    data = Array.isArray(data) ? data : data.text;

    if (photos)
      return data.map((a, i) => {
        const isChecked = checked[id] === a;

        return (
          <PhotoLabel htmlFor={a} key={a}>
            <StyledPhoto src={photos[i]} alt={a}/>
            <InputWrapper checked={isChecked}>
              <Answer value={a} type='radio' id={a} name='radio' onChange={() => onClick(id, a)} checked={isChecked}/>
            </InputWrapper>
            <AnswerText>{a}</AnswerText>
          </PhotoLabel>
        )
      });

    else
      return data.map((a) => {
        const isChecked = checked[id] === a;

        return (
            <StyledLabel htmlFor={a}
                         key={a}>
              <InputWrapper checked={isChecked}>
                <Answer value={a}
                        type='radio'
                        id={a}
                        name='radio'
                        onChange={() => onClick(id, a)}
                        checked={isChecked}/>
              </InputWrapper>
              <AnswerText padding={true}>{a}</AnswerText>
            </StyledLabel>
        )
      });
  };

  return (
    <StyledRadio key={id}>
      <Question>
        {question}
      </Question>
      <AnswerWrapper isPhoto={!!answers[branch].photos}>
        {!answers[branch].photos ?
          <CenterWrapper>
            {renderAnswer(answers[branch])}
          </CenterWrapper> :
          renderAnswer(answers[branch])}
      </AnswerWrapper>
    </StyledRadio>
  )
};

export default Radio;
